"""Utilities for modelling and solving the Water Sort Puzzle."""
